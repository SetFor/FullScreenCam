  The package contains components which was developed by users of the AlphaControls package. All components are free for using and available with sources.

  List of components included in the package at moment :
TacScrollPanel - fully skinned analog of TJvScrollMax from Jvcl package;
TacCheckComboBox - combobox with dropped down checklistbox;
TacFloatPanel - panel which may be moved and resized by mouse in trun-time;
TacListView - ListView with a lot of additional features

  Contact us please if you have any questions, comments or suggestions: support@alphaskins.com
